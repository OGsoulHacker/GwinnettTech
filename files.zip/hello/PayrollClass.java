package hello;
import java.util.Scanner;

public class PayrollClass {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);// Making scanner object

        PayRoll payroll = new PayRoll();//Making payroll object

        payroll.setHoursArray(input);//setter function to set hours
        payroll.setPayRateArray(input);//setter function to set PayRate
        payroll.calculateWagesArray();//calculating 'Wages' for each employee
// using getter function for each array to get the 'private' arrays
        int employseid[] = payroll.getEmployseIDArray();
        int hours[] = payroll.getHoursArray();
        double payRate[] = payroll.getPayRateArray();
        double wages[] = payroll.getWagesArray();

        System.out.println("employeeID\thours\tpayRate\twages");// displaying the report output
        for(int i = 0;i < payroll.arrayLength; i++)
            System.out.println(employseid[i]+"\t\t"+hours[i]+"\t"+payRate[i]+"\t"+wages[i]);
//closing the scanner object 'in'
        input.close();
    }
}
//=====================================================================================================
class PayRoll {
    static final int arrayLength = 7;//Declares static and constant ('Final') variable 'arrayLength' to store length of the array
    private int employseid[];//Declaring employee ID array
    private int hours[];//Declaring hours array
    private double payRate[];//Declaring payRate array
    private double wages[];//Declaring wages array
    PayRoll()// 'Payroll' constructor to initialize 'employseid' and define the size of other arrays
    {
        this.employseid = new int[]{56588, 45201, 78951, 87775, 84512, 13028, 75804};
        this.hours = new int[arrayLength];
        this.payRate = new double[arrayLength];
        this.wages = new double[arrayLength];
    }
    int[] getEmployseIDArray()//'getEmployseIDArray' - a getter function to return the 'employseid' array
    {
        return this.employseid;
    }
    //'setHoursArray' used as setter function to set the hours array
    //takes 'Scanner' object as parameter as input to read the input for number of hours from user using STDIN
    void setHoursArray(Scanner input)
    {
        for (int i = 0; i < arrayLength; i++)
        {
            System.out.println("Enter the number of hours for employee "+(i+1));
            this.hours[i] = input.nextInt();// reading the value for ith employee's number of hours using 'Scanner' object 'input'
        }
    }
    int[] getHoursArray()// 'getHoursArray' a getter function to return the 'hours' array as the output
    {
        return this.hours;
    }
    // 'setPayRateArray' used as setter function to set the pay rate for each employee
    // it takes 'Scanner' object as parameter as input to read the input for pay rate from user using STDIN
    void setPayRateArray(Scanner input)
    {
        for (int i = 0; i < arrayLength; i++)
        {
            System.out.println("Enter the pay rate for employee "+(i+1));
    // reading the value for ith employee's pay rate using 'Scanner' object 'in'
            this.payRate[i] = input.nextDouble();
        }
    }
    // 'getPayRateArray' a getter function to return the 'payRate' array as the output
    double[] getPayRateArray()
    {
        return this.payRate;
    }

    // 'findIndex' - function
    // takes the employeeID 'empID' as input (parameter)
    // return the index of array 'employseid' at which 'empID' is present
    // if 'empID' is not present then -1 is returned
    int findIndex(int empID)
    {
        for(int i = 0; i < arrayLength; i++)
        {
            if(this.employseid[i] == empID)
                return i;
        }
        return -1;
    }
    // 'getWages' - function as required in the problem
    // employeeID is passed as input (parameter)
    // first array index of employee with the emplyeeID is found using 'findIndex' function
    // then 'grossPay' is calculated by multiplying 'hours' with 'payRate' for the 'empIndex'
    // finally 'grossPay' is round off to 2 decimal places and returned
    double getWages(int employeeID)
    {
        int empIndex = findIndex(employeeID);
        double grossPay = this.hours[empIndex] * this.payRate[empIndex];
        grossPay = (Math.round(grossPay * 100.00)) / 100.00; // rounding off to 2 decimal places
        return grossPay;
    }
    // 'calculateWagesArray' - function to compute the array 'wages'
    // 'getWages' function is used on each 'employseid' element
    void calculateWagesArray()
    {
        for (int i = 0; i < arrayLength; i++)
        {
            this.wages[i] = this.getWages(this.employseid[i]);
        }
    }
    // 'getWagesArray' - getter function to return wages array
    double[] getWagesArray()
    {
        return this.wages;
    }
}