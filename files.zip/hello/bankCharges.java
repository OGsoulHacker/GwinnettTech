package hello;
import java.util.Scanner; // Import the Scanner class
public class bankCharges {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //initialization of variables
        double baseFee = 10.00;
        double checkFee = 0;

        System.out.println("Welcome to Wells Fargo!");
        System.out.println("Enter number of checks written this month: ");
        double numOfChecks = input.nextDouble();

        if (numOfChecks < 60) {
            if (numOfChecks >= 40) {
                checkFee = baseFee + 0.06;//Service fee for the month
                System.out.println("Monthly Service Fee: $" + checkFee);
            } else if (numOfChecks >= 20) {
                checkFee = baseFee + 0.08;//Service fee for the month
                System.out.println("Monthly Service Fee: $" + checkFee);
            }else{
                checkFee = baseFee + 0.10;//Service Fee for the month
                System.out.println("Monthly Service Fee: $" + checkFee);
            }
        }else{
            checkFee = baseFee + 0.04;//Service fee for the month
            System.out.println("Monthly Service Fee: $" + checkFee);
        }
    }
}
